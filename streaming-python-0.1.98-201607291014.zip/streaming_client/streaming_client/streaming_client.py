# coding: utf-8


from __future__ import absolute_import

import getpass

# python 2 and python 3 compatibility library
# from six import iteritems

from .configuration import Configuration
from .api_client import ApiClient
from .apis.default_api import DefaultApi
import os
import getpass
# import apis into api package


class StreamingClient(DefaultApi):
    """
    NOTE:Wrapper class for scheuler client
    """

    def __init__(self, host=None):
        #BluemixIDToken = getpass.getpass('ibm.ax.token')
        BlueIDToken = getpass.getpass('ibm.ax.token')
        Token = "Bearer " + BlueIDToken

        env = os.environ.get('APP_ENV_ENVIRONMENT')
        domain = os.environ.get('APP_ENV_BM_DOMAIN')

        #check environment
        # http://169.45.142.4:12001/streaming
        if host is None:
            if env == "prod" and domain == 'ng.bluemix.net':
                host = "http://streaming-prod.spark.bluemix.net:12201/streaming"
            elif env=="prod" and domain == 'stage1.ng.bluemix.net':
                host = "http://169.55.206.62:12201/streaming"
            elif env=="dev" and domain == 'stage1.ng.bluemix.net':
                host = "http://169.55.206.62:12201/streaming"
            else:
                host ="http://169.55.206.62:12201/streaming"

        api_client = ApiClient(host)

        api_client.set_default_header("Authorization",Token)
        super(self.__class__,self).__init__(api_client)


