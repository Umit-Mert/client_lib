from setuptools import setup

setup(name='ibm-sparkpipeline',
      version='0.1',
      description='Pipeline library',
      url='https://github.ibm.com/NGP-TWC/platform-pipeline/',
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=['pipeline'],
      zip_safe=False)
