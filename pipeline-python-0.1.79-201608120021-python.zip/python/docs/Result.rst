pipeline.Result module
======================

Module Context
--------------

.. automodule:: pipeline.Result
    :members:
    :undoc-members:
